"""FashionMNISTCNN 全体の理論 MACs。

参照元:
    notebooks/20_fashion_mnist/cnn/02_cnn_linear_svd.ipynb
    notebooks/20_fashion_mnist/cnn/04_cnn_conv_svd.ipynb
    notebooks/20_fashion_mnist/cnn/05_cnn_conv_linear_svd.ipynb

層単位の計算は ``metrics.macs``。ここは 28×28 / 14×14 の
Fashion-MNIST CNN 用の集計だけを置く。
"""

from .macs import (
    compressed_conv2d_macs,
    compressed_linear_macs,
    conv2d_macs,
    linear_macs,
)

CONV1_OUTPUT_HW = (28, 28)
CONV2_OUTPUT_HW = (14, 14)


def estimate_cnn_linear_macs(model, fc1_rank, verbose=True):
    """fc1 だけを分解したときの Linear 部 MACs・削減率を比較する。

    02 / 03 と同じく、比較対象は ``fc1`` と ``fc2`` のみ。
    """
    baseline_macs = linear_macs(model.fc1) + linear_macs(model.fc2)
    compressed_macs = (
        compressed_linear_macs(
            model.fc1.weight.shape[0],
            model.fc1.weight.shape[1],
            fc1_rank,
        )
        + linear_macs(model.fc2)
    )
    compute_reduction_rate = 1.0 - compressed_macs / baseline_macs

    if verbose:
        print("Baseline MACs:", baseline_macs)
        print("Compressed MACs:", compressed_macs)
        print(f"Compute reduction: {compute_reduction_rate:.2%}")

    return baseline_macs, compressed_macs, compute_reduction_rate


def estimate_cnn_conv2_macs(model, conv2_rank, verbose=True):
    """conv2 だけを分解したときの MACs・削減率を比較する。

    conv2 の出力は pool1 後の 14×14。04 と同じく比較対象は conv2 のみ。
    """
    out_h, out_w = CONV2_OUTPUT_HW
    baseline_macs = conv2d_macs(model.conv2, out_h, out_w)
    compressed_macs = compressed_conv2d_macs(
        model.conv2,
        conv2_rank,
        out_h,
        out_w,
    )
    compute_reduction_rate = 1.0 - compressed_macs / baseline_macs

    if verbose:
        print("Baseline MACs:", baseline_macs)
        print("Compressed MACs:", compressed_macs)
        print(f"Compute reduction: {compute_reduction_rate:.2%}")

    return baseline_macs, compressed_macs, compute_reduction_rate


def estimate_cnn_macs(model, conv2_rank, fc1_rank, verbose=True):
    """FashionMNISTCNN 全体の MACs・削減率を比較する。

    Baseline: conv1 + conv2 + fc1 + fc2
    Compressed: conv1 + 分解 conv2 + 分解 fc1 + fc2

    conv1 出力 28×28、conv2 出力 14×14 は現在の CNN で固定する。
    """
    conv1_h, conv1_w = CONV1_OUTPUT_HW
    conv2_h, conv2_w = CONV2_OUTPUT_HW

    conv1_layer_macs = conv2d_macs(model.conv1, conv1_h, conv1_w)
    conv2_baseline_macs = conv2d_macs(model.conv2, conv2_h, conv2_w)
    conv2_compressed_macs = compressed_conv2d_macs(
        model.conv2,
        conv2_rank,
        conv2_h,
        conv2_w,
    )
    fc1_baseline_macs = linear_macs(model.fc1)
    fc1_compressed_macs = compressed_linear_macs(
        model.fc1.in_features,
        model.fc1.out_features,
        fc1_rank,
    )
    fc2_layer_macs = linear_macs(model.fc2)

    baseline_macs = (
        conv1_layer_macs
        + conv2_baseline_macs
        + fc1_baseline_macs
        + fc2_layer_macs
    )
    compressed_macs = (
        conv1_layer_macs
        + conv2_compressed_macs
        + fc1_compressed_macs
        + fc2_layer_macs
    )
    reduction = 1.0 - compressed_macs / baseline_macs

    if verbose:
        print("Baseline total MACs:", baseline_macs)
        print("Compressed total MACs:", compressed_macs)
        print(f"Compute reduction: {reduction:.2%}")

    return baseline_macs, compressed_macs, reduction
